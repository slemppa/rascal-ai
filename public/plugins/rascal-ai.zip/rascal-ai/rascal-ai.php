<?php
/**
 * Plugin Name: Rascal AI - Automaattinen SEO
 * Description: Tällä lisäosalla varmistat, että sivustosi hakukonenäkyvyys (SEO) pysyy ajan tasalla automaattisesti.
 * Version: 2.1
 * Author: Rascal AI
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Rascal_Fox_Manager {

    private $namespace = 'rascal-ai/v1';
    private $route     = '/update-meta';

    public function __construct() {
        add_action('rest_api_init', [$this, 'register_api_routes']);
        add_action('admin_menu', [$this, 'add_admin_menu']);
    }

    /**
     * HALLINTAPANEELI
     */
    public function add_admin_menu() {
        // Tässä on kettu-ikoni muutettuna koodiksi (SVG Base64), jotta se näkyy valikossa heti.
        $fox_icon = 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0iI2U2N2UyMiI+PHBhdGggZD0iTTIxLjUgNS41bC01IDQuNS00LjUtMi41LTQuNSAyLjUtNSA0LjVjMCAwIDEuNSA5IDUuNSAxMyAxLjUgMS41IDQgMS41IDQgMS41czIuNSAwIDQtMS41YzQtNCA1LjUtMTMgNS41LTEzeiIvPjwvc3ZnPg==';

        add_menu_page(
            'Rascal AI',
            'Rascal AI',
            'manage_options',
            'rascal-ai-settings',
            [$this, 'render_admin_page'],
            $fox_icon, // <-- Tässä vaihdettiin ikoni ketuksi
            100
        );
    }

    public function render_admin_page() {
        $api_url = rest_url($this->namespace . $this->route);
        $is_yoast_active = defined('WPSEO_VERSION');
        ?>
        <div class="wrap">
            <h1 style="font-size: 3em;">🦊 Rascal AI</h1>
            <br>
            <div style="background:#fff; padding:30px; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); max-width: 800px;">
                
                <h2 style="margin-top:0;">Kaikki toimii!</h2>
                <p style="font-size: 1.1em; line-height: 1.5;">
                    Tällä lisäosalla varmistat, että <strong>Rascal AI</strong> saa yhteyden sivustolle. 
                    Se huolehtii taustalla siitä, että artikkeliesi otsikot, kuvaukset ja avainsanat ovat aina optimoituja hakukoneita varten.
                </p>

                <hr style="margin: 20px 0; border: none; border-bottom: 1px solid #eee;">

                <h3>Tilan tarkistus</h3>
                <?php if ($is_yoast_active): ?>
                    <div style="background: #e7f9e7; border-left: 4px solid #46b450; padding: 15px;">
                        <p style="margin: 0; color: #2e5c31; font-weight: bold;">✅ Yhteys Yoast SEO -työkaluun on kunnossa.</p>
                        <p style="margin: 5px 0 0 0;">Agentti voi nyt päivittää tietoja onnistuneesti.</p>
                    </div>
                <?php else: ?>
                    <div style="background: #fbeaea; border-left: 4px solid #dc3232; padding: 15px;">
                        <p style="margin: 0; color: #cc0000; font-weight: bold;">⚠️ Yoast SEO -lisäosaa ei löytynyt.</p>
                        <p style="margin: 5px 0 0 0;">Asennathan Yoast SEO:n, jotta optimointi toimii täydellisesti.</p>
                    </div>
                <?php endif; ?>

                <br><br>

                <h3>Yhdistäminen agenttiin</h3>

                <br><br><br>
                
                <details style="color: #666; font-size: 0.9em; border-top: 1px solid #eee; padding-top: 15px;">
                    <summary style="cursor: pointer; font-weight: bold;">🔧 Näytä tekniset tiedot (Kehittäjille)</summary>
                    <p>JSON-rakenne n8n-automaatiota varten:</p>
<pre style="background: #f0f0f1; padding: 10px; border-radius: 5px; color: #333;">
{
  "post_id": 123,
  "yoast_title": "Otsikko",
  "yoast_description": "Kuvaus",
  "yoast_keyword": "avainsana"
}
</pre>
                </details>

            </div>
        </div>
        <?php
    }

    /**
     * API-REITIT
     */
    public function register_api_routes() {
        register_rest_route( $this->namespace, $this->route, [
            'methods'             => 'POST',
            'callback'            => [$this, 'update_yoast_meta'],
            'permission_callback' => [$this, 'check_route_permission'],
            'args'                => [
                'post_id' => [
                    'required' => true,
                    'validate_callback' => function($param) { return is_numeric($param); }
                ],
            ],
        ] );
    }

    public function update_yoast_meta( WP_REST_Request $request ) {
        $post_id = $request->get_param('post_id');

        if ( ! current_user_can('edit_post', $post_id) ) {
            return new WP_Error( 'rest_forbidden', 'Ei oikeuksia.', ['status' => 403] );
        }

        $fields_map = [
            'yoast_title'       => '_yoast_wpseo_title',
            'yoast_description' => '_yoast_wpseo_metadesc',
            'yoast_keyword'     => '_yoast_wpseo_focuskw',
        ];

        $updated = false;
        foreach ( $fields_map as $param_name => $meta_key ) {
            if ( $request->has_param( $param_name ) ) {
                update_post_meta( $post_id, $meta_key, $request->get_param( $param_name ) );
                $updated = true;
            }
        }

        if ( ! $updated ) {
            return new WP_Error( 'no_fields', 'Ei dataa.', ['status' => 400] );
        }

        return new WP_REST_Response( ['success' => true], 200 );
    }

    public function check_route_permission() {
        return current_user_can( 'edit_posts' );
    }
}

new Rascal_Fox_Manager();
